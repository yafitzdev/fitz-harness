# DeepSeek V4 Pro 路由测试页（2026-08-15/16）

**官方 API 实测 · 全部数据可复现 · 原始记录在 `routing-probe/results-*.json`**

## 一句话结论

V4 Pro 的行为沿 persona 轴是**清晰三分**：RL 接口带 [0, 0.025]（稳定"神"）、竞争陷阱带 [0.025, 0.455]（高熵反路由）、doer 带 [0.455, 1]（稳定"鬼"反转）。**路由 = 在正确任务上选正确接口**：维护→RL 接口（小名 Project2 实测 98/99 vs Standard 91），构建→doer 接口（Mario 10/10 vs 锚定 6/10）。竞争带永不触碰。

## 1. 相变结构（n=570，协议 B+D）

```
ψ₁ = P(minimal-like)，追加注入轴 x∈[0,1]
  x < 0.025   → 0.925   （RL 接口带）
  0.025–0.455 → 0.464   （竞争陷阱带）
  x ≥ 0.455   → 0.073   （doer 带）
突变中心 xc = 0.192，bootstrap 95% CI [0.151, 0.229]
三段模型 AIC 668.7 < logit 697.9 —— 三分确凿
```

加密扫描（[0, 0.35] 步长 0.01）显示竞争带内每点 minimal-like 在 **0%–80% 剧烈波动**——吸引子竞争的直接观测（点内方差，非测量噪声）。

## 2. 竞争带判别矩阵（n=5/点，协议 E2，140 请求）

| x | 判别力（maint−green） | 判定 |
|---|---|---|
| 0.03 | −9.2 | **反路由** |
| 0.08 | −10.6 | **反路由峰值** |
| 0.15 | −3.4 | 反路由 |
| 0.20 | +0.4 | 无判别 |
| 0.30 | −4.6 | 反路由 |
| 0.40 | +0.2 | 无判别 |
| 0.50 | −3.8 | 反路由 |

**9/12 反路由、2 无判别、0 自路由**。机制：修复任务被 spec 锚稳定拉住（plan +1.0~+1.4），构建任务在竞争噪声里随机掉进"更 plan"（+0.6~+11.6）→ green 变 plan = 反路由。**bandOf 的 spec 安全边界实测是 0.03，不是 0.2**。

## 3. weak 域判别（n=10，协议 C）

| persona | 判别力 |
|---|---|
| router-v2（few-shot） | **+2.6** |
| react | +2.2 |
| w7 | +2.0 |
| neutral | +1.1 |
| w6c（spec 句+classify） | +0.2（无效） |
| spec | **−4.5（反路由）** |

**w6c 已从 router-pro 移除**（spec 句+classify 组合在 Pro 上是反路由的）。

## 4. 长链路（协议 G-pro，9 链路 × 3 阶段）

- Pro 全程 doer 锁定（路径承诺），**无阶段感知 lean**——链中任务内容不能翻转风格
- **Okay token 触发对 Pro 无效**（fix 深度 137–280 vs 基线 236–1826，无增益）——Mid-Think 触发是 Flash 现象
- build 阶段倾向文本回复不调工具（doer 接口 + write-first 面修正此行为，Mario code-mode 10/10 证据）

## 5. RL 接口增强验证（协议 H，进行中）

| 配置 | 状态 | 说明 |
|---|---|---|
| RL 接口 + 32K | 待 H 完成 | Flash 同协议 100% 行动、推理 4.3× 降 |
| RL 接口 + 256K | 慢（Pro 特性） | xiaobright issue #11：schema 锚定在 256K 下仍有效（无需 cap） |
| standard + 32K/256K | 对照 | 预期 73–101K 推理/低行动（Flash 同协议数据） |

## 6. 与 Flash 的关键差异

| | Flash | Pro |
|---|---|---|
| 序参量形态 | 渐变型（无相变，中心 ~0.95） | **突变型（xc=0.19，三分）** |
| 竞争带 | 无（[0, 0.55] 直接饱和） | **有（[0.03, 0.455] 反路由）** |
| Okay 触发 | **+40–115% 推理且保持行动** | 无效 |
| weak 判别 | +4.6（router-v2） | +2.6（router-v2） |
| spec+classify | −2.8（反路由） | +0.2（无效） |

## 7. 数据文件

- `results-B-deepseekv4pro-msudo1iv.json`（21 点粗扫 n=10）
- `results-D-deepseekv4pro-msudsje7.json`（[0,0.35] 加密 n=10）
- `results-C-deepseekv4pro-msudqz7v.json`（weak 判别 n=10）
- `results-E2-deepseekv4pro-msuj2tu6.json`（竞争带判别 n=5）
- `results-G-deepseekv4pro-msukwdm8.json`（长链路 9 条）
- `results-H-deepseekv4pro-msukxjz2.json`（RL 接口增强，进行中）
- 拟合：`fit-final-deepseekv4pro.json` / `fit-final.mjs`
